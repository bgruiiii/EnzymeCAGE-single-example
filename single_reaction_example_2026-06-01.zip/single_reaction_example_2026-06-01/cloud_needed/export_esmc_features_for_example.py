#!/usr/bin/env python
"""Export ESM-C features for the EnzymeCAGE single GitHub example on Windows cloud."""

import json
import os
import pickle
import shutil
from pathlib import Path

import numpy as np
import torch

UID = "Q7M0V7"
SEQUENCE = 'MGAEVFHSLKKVLGEKGLASGVGDEGGFAPNLGSNIRRAGYTAVISHRVAKYNQLLR'

ESM_ROOT = Path(r"G:\esm\ESM-C_600M")
NODE_NPZ = ESM_ROOT / "node_level" / f"{UID}.npz"
SEQ2FEATURE = ESM_ROOT / "protein_level" / "seq2feature.pkl"
POCKET_DIR = ESM_ROOT / "pocket_node_feature_full_valid_sharded_20260422"
POCKET_POINTER = POCKET_DIR / "esm_node_feature.pt"
OUT_DIR = Path.cwd() / "single_example_esmc_export"


def torch_load(path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def load_pocket_feature(uid):
    pointer = torch_load(POCKET_POINTER)
    if not (isinstance(pointer, dict) and "__format__" in pointer):
        return pointer[uid]
    manifest_path = Path(pointer["manifest_path"])
    if not manifest_path.is_absolute():
        manifest_path = POCKET_POINTER.parent / manifest_path
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    shard_name = manifest["uid_to_shard"][uid]
    shard = torch_load(manifest_path.parent / manifest["shard_dir"] / shard_name)
    return shard[uid]


OUT_DIR.mkdir(parents=True, exist_ok=True)
shutil.copyfile(NODE_NPZ, OUT_DIR / f"{UID}_esm_c_sequence_node.npz")

with open(SEQ2FEATURE, "rb") as f:
    seq2feature = pickle.load(f)
seq_mean = np.asarray(seq2feature[SEQUENCE], dtype=np.float32)
np.save(OUT_DIR / f"{UID}_esm_c_sequence_mean.npy", seq_mean)

pocket_node = np.asarray(load_pocket_feature(UID), dtype=np.float32)
np.save(OUT_DIR / f"{UID}_esm_c_pocket_node.npy", pocket_node)

summary = {
    "UniprotID": UID,
    "sequence_node_npz": str(NODE_NPZ),
    "sequence_mean_shape": list(seq_mean.shape),
    "pocket_node_shape": list(pocket_node.shape),
}
(OUT_DIR / f"{UID}_esm_c_export_summary.json").write_text(
    json.dumps(summary, indent=2), encoding="utf-8"
)
print(json.dumps(summary, indent=2))
