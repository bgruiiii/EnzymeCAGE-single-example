# Cloud-needed ESM-C features

本示例包已经包含本机可提取的反应、GVP/pocket、微生物结果。

仍需要从云端 `G:\esm` 导出 3 个 ESM-C 文件：

| 文件 | 云端来源 |
|---|---|
| `Q7M0V7_esm_c_sequence_node.npz` | `G:\esm\ESM-C_600M\node_level\Q7M0V7.npz` |
| `Q7M0V7_esm_c_sequence_mean.npy` | 从 `G:\esm\ESM-C_600M\protein_level\seq2feature.pkl` 用本序列作为 key 提取 |
| `Q7M0V7_esm_c_pocket_node.npy` | 从 `G:\esm\ESM-C_600M\pocket_node_feature_full_valid_sharded_20260422` 按 UID 提取 |

云端运行：

```powershell
python export_esmc_features_for_example.py
```

运行后会生成 `single_example_esmc_export/`，把里面 4 个文件复制回本示例包的
`features/enzyme/` 或单独随包上传即可。
